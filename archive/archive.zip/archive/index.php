<?php 
	include "meca/config.php";
	include "meca/PHP.php";
	doHTML();
?>